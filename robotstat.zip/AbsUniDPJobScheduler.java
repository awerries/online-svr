/**
 * @Description: Greedy Dynamic Programming
 *
 * @Author        Create/Modi     Notes
 * Xiao-Feng Xie   Nov 04, 2013    SchIC-V2.1
 * Xiao-Feng Xie   Oct 26  2010    
 *
 * @version M01.00.00
 * @since M01.00.00
 */

package TLC.control.intersection.transition;

import TLC.global.*;

public abstract class AbsUniDPJobScheduler implements IDPJobScheduleEngine {
  protected double[] Count;
  //fixed
	protected InternalPhaseInfo internalPhaseInfo;
	protected SinglePhaseEdgeInfo singlePhaseEdgeInfo;
	
	protected boolean isSoftFlag;
	
	//temp
  protected int[] mJobID;
  protected DualIAlienArray jobIndices;
  protected int nRoutes;
  
 //jobs
  protected int[] fullJobBounds;
  protected int nJobSpace;
  protected int nJobs;
	protected int[] NumJob;
  

  public AbsUniDPJobScheduler() {}

	public void initiate(InternalPhaseInfo internalPhaseInfo) {
		this.internalPhaseInfo = internalPhaseInfo;
    
		nRoutes = internalPhaseInfo.Order.length;
    mJobID = new int[nRoutes];
    fullJobBounds = new int[nRoutes]; 
    this.isSoftFlag = internalPhaseInfo.isSoft();
    initDPTables(1000);
	}
	
	public void DyProg(int StartRoute, int elapseTime, int offsetTime, SinglePhaseEdgeInfo singlePhaseEdgeInfo, BasicJobBlockSData dpData, DPSOutData2 dpSOutData) {
		this.singlePhaseEdgeInfo = singlePhaseEdgeInfo;
		this.Count = dpData.Count;
		DyProg(
				StartRoute,
				elapseTime,
				dpData.NumJob,
				dpData.Weight,
				dpData.JobStart,
				dpData.JobEnd,
				dpData.Info,
				offsetTime);
		getOutput2(dpSOutData);
	}
	
	public void DyProg(
			int   StartRoute,
			int   elapseTime,
			int[] NumJob,
			double[] Weight,
			int[] JobStart,
			int[] JobEnd,
			JobInfo[] Info, 
			int offsetTime) {
		
		GlobalTools.CPUTimeCostCounter.setStart(GlobalCounter.CalcTime);
		System.arraycopy(NumJob, 0, fullJobBounds, 0, nRoutes);
		for (int i=0; i<nRoutes; i++) {
			fullJobBounds[i]++; 
		}
		nJobSpace = DimTransformer.getSpaceSize(fullJobBounds);
		nJobs = DimTransformer.getLinearSize(NumJob);
		this.NumJob = NumJob;
		
		initDPTables(nJobSpace);

		//give initial values of DP tables (including cost, end time, and input route index)
		initFirstElement(StartRoute, elapseTime, offsetTime, singlePhaseEdgeInfo.StartupTime);

		jobIndices.clear();
		jobIndices.addElement(0);
		
		int startIndex = 0, endIndex = 1;
		int finishedJobCounts = 0;
		int nRoutes = fullJobBounds.length;
		while (finishedJobCounts < nJobs) {
			//get all job indices with the total number of jobs "finishedJobCounts"
			for (int i=startIndex; i<endIndex; i++) {
				int id = jobIndices.getElementAt(i);
				DimTransformer.intToMutiD(mJobID, id, fullJobBounds);
				for (int j=0; j<nRoutes; j++) {
					if (mJobID[j]==(fullJobBounds[j]-1)) {
						continue;
					}
					mJobID[j]++;
					jobIndices.addElement(DimTransformer.multiDToInt(mJobID, fullJobBounds));
					mJobID[j]--;
				}
			}
			startIndex = endIndex;
			endIndex = jobIndices.getSize();
			//update DP tables for these job indices
			for (int i=startIndex; i<endIndex; i++) {
				int id = jobIndices.getElementAt(i);
				DimTransformer.intToMutiD(mJobID, id, fullJobBounds);
				updateTable(id, mJobID, singlePhaseEdgeInfo, internalPhaseInfo, Weight, JobStart, JobEnd, Info, NumJob);
			}
			finishedJobCounts ++;
		}
		
		GlobalTools.CPUTimeCostCounter.setEnd(GlobalCounter.CalcTime);
	}
	
	abstract protected void getOutput2(DPSOutData2 dpSOutData);
	
	abstract protected void initFirstElement(int StartRoute, int elapseTime, int offsetTime, int[] StartupTime);
	
	abstract protected void updateTable(int sJobID, int[] mJobID, 		//job index (sJobID, mJobID)
			SinglePhaseEdgeInfo singlePhaseEdgeInfo, InternalPhaseInfo internalPhaseInfo, double[] Weight, int[] JobStart, int[] JobEnd, JobInfo[] Info, int[] NumJob); // input values 
	
	abstract protected void initDPTables(int nJobSpace);

};