/**
 * @Description: Greedy Dynamic Programming
 *
 * @Author        Create/Modi     Notes
 * Xiao-Feng Xie   Nov 04, 2013    SchIC-V2.1
 * Xiao-Feng Xie   Oct 26  2010    
 *
 * @version M01.00.00
 * @since M01.00.00
 */

package TLC.control.intersection.transition;

import java.util.Arrays;

import TLC.global.*;
import TLC.data.packet.*;

public class SDP1MinJobScheduler extends AbsUniDPJobScheduler {
	private double[][] valueTable;
  private int[][] staTimeTable;
	private int[][] endTimeTable;
	private int[][] inputRIDTable;
  private int[][] elapseTable;
  private boolean[][] firstPhaseTable; //maybe not useful
  private double[] Weight;
  
  protected JobBlockDeltaData jobBlockDeltaData = new JobBlockDeltaData();
  
  
  public SDP1MinJobScheduler() {}
	
  protected void getOutput2(DPSOutData2 dyOut) {
    //get the route index of the last job of the best solution
    double minV = Double.MAX_VALUE;
    int outputRID = 0;
    for (int i=0; i<nRoutes; i++) {
      if (valueTable[nJobSpace-1][i]<minV) {
        minV = valueTable[nJobSpace-1][i];
        outputRID = i;
      }
    }
    dyOut.cost = minV;
    
    //retrieve output
    int jobID = nJobSpace-1;
    int linJobIndex;
    dyOut.nJobs = nJobs + dyOut.offsetIndex;
    for(int i=0; i<nJobs; i++) {
      dyOut.routeIndices[dyOut.offsetIndex+nJobs-1-i] = outputRID;
      CountPacket durationPacket = dyOut.getDurationPackets(dyOut.offsetIndex+nJobs-1-i); 
      DimTransformer.intToMutiD(mJobID, jobID, fullJobBounds);
      durationPacket.start_V  = staTimeTable[jobID][outputRID];
      durationPacket.end_V  = endTimeTable[jobID][outputRID];
      mJobID[outputRID]--;
      linJobIndex = DimTransformer.getLinearIndex(outputRID, mJobID[outputRID], NumJob);
      durationPacket.count = Weight[linJobIndex];
      outputRID = inputRIDTable[jobID][outputRID];
      jobID = DimTransformer.multiDToInt(mJobID, fullJobBounds);
    }
  }

	protected void initFirstElement(int StartRoute, int elapseTime, int offsetTime, int[] StartupTime) {
		Arrays.fill(valueTable[0], Double.MAX_VALUE);
		valueTable[0][StartRoute] = 0;
//		Arrays.fill(valueTable[0], 0);
		Arrays.fill(inputRIDTable[0], StartRoute);
		elapseTable[0][StartRoute] = elapseTime;
		endTimeTable[0][StartRoute] = offsetTime;
		firstPhaseTable[0][StartRoute] = true;
//		for (int i=0; i<nRoutes; i++) {
//			endTimeTable[0][i] = internalPhaseInfo.getDeltaEnd(i, StartRoute)+offsetTime;
//		}
	}
	
	protected void updateTable(int sJobID, int[] mJobID, 		//job index (sJobID, mJobID)
			SinglePhaseEdgeInfo singlePhaseEdgeInfo, InternalPhaseInfo internalPhaseInfo, double[] Weight, int[] JobStart, int[] JobEnd, JobInfo[] Info, int[] NumJob) // input values 
	{
	  this.Weight = Weight;
		int i, j, ii, actualEndT = 0, permitT, actualT = 0, deltaMinT, swPermitT, switchBackT;
		double Lateness;
		boolean isSwitchBack;
		int nRoutes = internalPhaseInfo.Order.length;
		for(i=0; i<nRoutes; i++) {
			valueTable[sJobID][i] = Double.MAX_VALUE;
			if (mJobID[i] == 0) continue;
			mJobID[i] --;
			ii = DimTransformer.multiDToInt(mJobID, fullJobBounds);
      int index = DimTransformer.getLinearIndex(i, mJobID[i], NumJob);
			
			for(j=0; j<nRoutes; j++) {
				if (valueTable[ii][j]==Double.MAX_VALUE) {
					continue;
				}
				firstPhaseTable[sJobID][j] = firstPhaseTable[ii][j];
				
				permitT = endTimeTable[ii][j];
				
				deltaMinT = 0;
				if (elapseTable[ii][j] < internalPhaseInfo.MinTime[j]) deltaMinT = internalPhaseInfo.MinTime[j]-elapseTable[ii][j];
				
				isSwitchBack = false;
				if (i!=j) {  
				  if (elapseTable[ii][j] < internalPhaseInfo.MinTime[j]) permitT += deltaMinT; //check minimum green time
				  firstPhaseTable[sJobID][j] = false;
				} 
				//switch-back
				
				permitT += internalPhaseInfo.getDeltaEnd(i, j);  // phase switching time
				actualT = singlePhaseEdgeInfo.getActualStart(permitT, JobStart[index], i, i==j); //start-up lost time
				
        JobBlockHandler.execute(jobBlockDeltaData, JobStart[index], JobEnd[index], Weight[index], Info[index], actualT, singlePhaseEdgeInfo.satFlowRate[i], isSoftFlag);
        actualEndT = jobBlockDeltaData.getDeltaEnd() + JobEnd[index];

        
        if (DiaoduSettings.UsePostProcess > 0 && i==j) {
          int newElapseTime = elapseTable[ii][j]+(actualEndT-endTimeTable[ii][j]);
          if (newElapseTime > internalPhaseInfo.MaxTime[i]) {
        	  //case 1: pre-switchback
            switchBackT = internalPhaseInfo.getSwitchBackTime(i)+singlePhaseEdgeInfo.StartupTime[i];
						swPermitT = switchBackT+permitT+deltaMinT;
						actualT = Math.max(JobStart[index], swPermitT);
						permitT = actualT - singlePhaseEdgeInfo.StartupTime[i];
						isSwitchBack = true;
						firstPhaseTable[sJobID][j] = false;
	
		        JobBlockHandler.execute(jobBlockDeltaData, JobStart[index], JobEnd[index], Weight[index], Info[index], actualT, singlePhaseEdgeInfo.satFlowRate[i], isSoftFlag);
		        actualEndT = jobBlockDeltaData.getDeltaEnd() + JobEnd[index];
          }
//          if (newElapseTime == internalPhaseInfo.MaxTime[i]) {
//          	int kkk=0;
//          	kkk++;
//          }          
        }

				
        Lateness = jobBlockDeltaData.getDeltaLateness()+valueTable[ii][j];


        if(Lateness < valueTable[sJobID][i] || (Lateness==valueTable[sJobID][i] && actualEndT < endTimeTable[sJobID][i]))	{ //greedy
					valueTable[sJobID][i] = Lateness;
					endTimeTable[sJobID][i] = actualEndT;
					staTimeTable[sJobID][i] = actualT;
					inputRIDTable[sJobID][i] = j;
					if (i==j && !isSwitchBack) {
						elapseTable[sJobID][i] = elapseTable[ii][j]+(actualEndT-endTimeTable[ii][j]);
	        } else {
	        	elapseTable[sJobID][i] = actualEndT - permitT;
	        }
				}
			}
			mJobID[i] ++;
		}
	}
	
	protected void initDPTables(int nJobSpace) {
		if (valueTable == null || nJobSpace>valueTable.length || nRoutes>valueTable[0].length) {
			valueTable = new double[nJobSpace][nRoutes];
			endTimeTable =  new int[nJobSpace][nRoutes];
			staTimeTable =  new int[nJobSpace][nRoutes];
			inputRIDTable = new int[nJobSpace][nRoutes];
			elapseTable = new int[nJobSpace][nRoutes];
			firstPhaseTable = new boolean[nJobSpace][nRoutes];
			jobIndices = new DualIAlienArray(nJobSpace*nRoutes+1);
		}
	}
};