/*     */ package TLC.control.intersection.transition;
/*     */ 
/*     */ import TLC.component.junction.structure.innerLogic.IInternalPhaseSkipStatusEngine;
/*     */ import TLC.global.DimTransformer;
/*     */ import TLC.global.GlobalString;
/*     */ import TLC.setting.ScaleSettings;
/*     */ import java.text.DecimalFormat;
/*     */ 
/*     */ public class BasicJobBlockSData
/*     */ {
/*     */   public int[] NumJob;
/*     */   public double[] Weight;
/*     */   public double[] Count;
/*     */   public int[] JobStart;
/*     */   public int[] JobEnd;
            public JobInfo[] Info;
/*     */ 
/*     */   public void initiate(int activePhaseNumber, int maxJobNumber)
/*     */   {
/*  30 */     this.NumJob = new int[activePhaseNumber];
/*  31 */     this.Weight = new double[maxJobNumber * activePhaseNumber];
/*  32 */     this.Count = new double[maxJobNumber * activePhaseNumber];
/*  33 */     this.JobStart = new int[maxJobNumber * activePhaseNumber];
/*  34 */     this.JobEnd = new int[maxJobNumber * activePhaseNumber];
              this.Info = new JobInfo[maxJobNumber * activePhaseNumber];
/*     */   }
/*     */ 
/*     */   public double getTotalCount()
/*     */   {
/*  39 */     double count = 0.0D;
/*  40 */     int totalJobNumber = getStartIndex(this.NumJob.length);
/*  41 */     for (int i = 0; i < totalJobNumber; i++) {
/*  42 */       count += this.Count[i];
/*     */     }
/*  44 */     return count;
/*     */   }
/*     */ 
/*     */   public int getStartIndex(int phaseIndex) {
/*  48 */     int startIndex = 0;
/*  49 */     for (int i = 0; i < phaseIndex; i++) {
/*  50 */       startIndex += this.NumJob[i];
/*     */     }
/*  52 */     return startIndex;
/*     */   }
/*     */ 
/*     */   public void addWeightAt(int phaseIndex, double weight)
/*     */   {
/*  57 */     int startIndex = getStartIndex(phaseIndex);
/*  58 */     this.Weight[startIndex] += weight;
/*     */   }
/*     */ 
/*     */   public BasicJobBlockSData getClone()
/*     */   {
/*  69 */     BasicJobBlockSData basicJobBlockSData = new BasicJobBlockSData();
/*  70 */     basicJobBlockSData.NumJob = ((int[])this.NumJob.clone());
/*  71 */     basicJobBlockSData.Weight = ((double[])this.Weight.clone());
/*  72 */     basicJobBlockSData.Count = ((double[])this.Count.clone());
/*  73 */     basicJobBlockSData.JobStart = ((int[])this.JobStart.clone());
/*  74 */     basicJobBlockSData.JobEnd = ((int[])this.JobEnd.clone());
              basicJobBlockSData.Info = ((JobInfo[])this.Info.clone());
/*  75 */     return basicJobBlockSData;
/*     */   }
/*     */ 
/*     */   public void copyTo(BasicJobBlockSData data) {
/*  79 */     System.arraycopy(this.NumJob, 0, data.NumJob, 0, this.NumJob.length);
/*  80 */     int linSize = DimTransformer.getLinearSize(this.NumJob);
/*  81 */     System.arraycopy(this.JobStart, 0, data.JobStart, 0, linSize);
/*  82 */     System.arraycopy(this.JobEnd, 0, data.JobEnd, 0, linSize);
/*  83 */     System.arraycopy(this.Count, 0, data.Count, 0, linSize);
/*  84 */     System.arraycopy(this.Weight, 0, data.Weight, 0, linSize);
              System.arraycopy(this.Info, 0, data.Info, 0, linSize);
/*     */   }
/*     */ 
/*     */   public double getPhaseVehicleCount(int phaseIndex) {
/*  88 */     double count = 0.0D;
/*  89 */     int startIndex = getStartIndex(phaseIndex);
/*  90 */     for (int j = 0; j < this.NumJob[phaseIndex]; j++) {
/*  91 */       count += this.Weight[(startIndex + j)];
/*     */     }
/*  93 */     return count;
/*     */   }
/*     */ 
/*     */   public double getPhaseVehicleCount(int phaseIndex, int maxTimeBound) {
/*  97 */     double count = 0.0D;
/*  98 */     int startIndex = getStartIndex(phaseIndex);
/*  99 */     for (int j = 0; j < this.NumJob[phaseIndex]; j++) {
/* 100 */       int jobIndex = startIndex + j;
/* 101 */       if (this.JobStart[jobIndex] >= maxTimeBound) {
/*     */         break;
/*     */       }
/* 104 */       if ((this.JobEnd[jobIndex] > maxTimeBound) && (this.JobEnd[jobIndex] > this.JobStart[jobIndex])) {
/* 105 */         count += this.Weight[(startIndex + j)] * (maxTimeBound - this.JobStart[jobIndex]) / (this.JobEnd[jobIndex] - this.JobStart[jobIndex]);
/* 106 */         break;
/*     */       }
/* 108 */       count += this.Weight[(startIndex + j)];
/*     */     }
/*     */ 
/* 111 */     return count;
/*     */   }
/*     */ 
/*     */   protected void copyJob(int routeIndex, int startJobIndex) {
/* 115 */     int totalJobNumber = getStartIndex(this.NumJob.length);
/* 116 */     System.arraycopy(this.Weight, startJobIndex, this.Weight, startJobIndex + 1, totalJobNumber - startJobIndex);
/* 117 */     System.arraycopy(this.Count, startJobIndex, this.Count, startJobIndex + 1, totalJobNumber - startJobIndex);
/* 118 */     System.arraycopy(this.JobStart, startJobIndex, this.JobStart, startJobIndex + 1, totalJobNumber - startJobIndex);
/* 119 */     System.arraycopy(this.JobEnd, startJobIndex, this.JobEnd, startJobIndex + 1, totalJobNumber - startJobIndex);
              System.arraycopy(this.Info, startJobIndex, this.Info, startJobIndex + 1, totalJobNumber - startJobIndex);
/* 120 */     this.NumJob[routeIndex] += 1;
/*     */   }
/*     */ 
/*     */   protected void boundJob(int routeIndex, int cuttingTimePoint) {
/* 124 */     int startJobIndex = getStartIndex(routeIndex);
/* 125 */     double remRatio = 0.0D;
/* 126 */     if (this.NumJob[routeIndex] > 0) cuttingTimePoint += this.JobStart[startJobIndex];
/* 127 */     while (startJobIndex < this.NumJob[routeIndex]) {
/* 128 */       if (this.JobEnd[startJobIndex] == this.JobStart[startJobIndex]) {
/* 129 */         if (cuttingTimePoint >= this.JobEnd[startJobIndex]) remRatio = 0.0D; else
/* 130 */           remRatio = 1.0D;
/*     */       }
/* 132 */       else remRatio = (this.JobEnd[startJobIndex] - cuttingTimePoint) / (double)(this.JobEnd[startJobIndex] - this.JobStart[startJobIndex]);
/*     */ 
/* 134 */       if (remRatio < 0.0D) {
/* 135 */         startJobIndex++;
				  continue;
/*     */       }
/* 138 */       if (remRatio >= 1.0D) {
/* 139 */         startJobIndex--;
				  break;
/*     */       }
/* 142 */         this.Weight[startJobIndex] *= (1.0D - remRatio);
/* 143 */         this.JobEnd[startJobIndex] = cuttingTimePoint;
				  break;
/*     */      
/*     */     }
/* 146 */     removeJobs(startJobIndex + 1, routeIndex);
/*     */   }
/*     */ 
/*     */   protected void removeJobs(int startJobIndex, int routeIndex) {
/* 150 */     int endJobIndex = getStartIndex(routeIndex) + this.NumJob[routeIndex];
/* 151 */     if (startJobIndex >= endJobIndex) return;
/* 152 */     int totalJobNumber = getStartIndex(this.NumJob.length);
/* 153 */     System.arraycopy(this.Weight, endJobIndex, this.Weight, startJobIndex, totalJobNumber - endJobIndex);
/* 154 */     System.arraycopy(this.Count, endJobIndex, this.Count, startJobIndex, totalJobNumber - endJobIndex);
/* 155 */     System.arraycopy(this.JobStart, endJobIndex, this.JobStart, startJobIndex, totalJobNumber - endJobIndex);
/* 156 */     System.arraycopy(this.JobEnd, endJobIndex, this.JobEnd, startJobIndex, totalJobNumber - endJobIndex);
              System.arraycopy(this.Info, endJobIndex, this.Info, startJobIndex, totalJobNumber - endJobIndex);
/* 157 */     this.NumJob[routeIndex] = startJobIndex;
/*     */   }
/*     */ 
/*     */   protected double cutJob(int routeIndex, int startJobIndex, int cuttingTimePoint) {
/* 161 */     double remRatio = 0.0D;
/* 162 */     if (this.JobEnd[startJobIndex] == this.JobStart[startJobIndex]) {
/* 163 */       if (cuttingTimePoint >= this.JobEnd[startJobIndex]) remRatio = 0.0D; else
/* 164 */         remRatio = 1.0D;
/*     */     }
/* 166 */     else {
				remRatio = (this.JobEnd[startJobIndex] - cuttingTimePoint) / (double)(this.JobEnd[startJobIndex] - this.JobStart[startJobIndex]);
			  }
/*     */ 
/* 168 */     if ((remRatio <= 0.0D) || (remRatio >= 1.0D)) return remRatio;
/*     */ 
/* 170 */     copyJob(routeIndex, startJobIndex);
/*     */ 
/* 176 */     this.Weight[startJobIndex] *= (1.0D - remRatio);
/* 177 */     this.Count[startJobIndex] *= (1.0D - remRatio);
/* 178 */     this.JobEnd[startJobIndex] = cuttingTimePoint;
/*     */ 
/* 180 */     this.Weight[(startJobIndex + 1)] *= remRatio;
/* 181 */     this.Count[(startJobIndex + 1)] *= remRatio;
/* 182 */     this.JobStart[(startJobIndex + 1)] = cuttingTimePoint;
/*     */ 
/* 186 */     return remRatio;
/*     */   }
/*     */ 
/*     */   public double getMinSwitchNonPhaseVehicleCount(int StartRoute, InternalPhaseInfo internalPhaseInfo, IInternalPhaseSkipStatusEngine internalPhaseCycleEngine) {
/* 190 */     double count = 0.0D;
/* 191 */     int maxTimeBound = internalPhaseInfo.getSwitchBackTime(StartRoute);
/* 192 */     for (int i = 0; i < this.NumJob.length; i++) {
/* 193 */       if ((i != StartRoute) && (!internalPhaseCycleEngine.isSkippableAt(i))) {
/* 194 */         count += getPhaseVehicleCount(i, maxTimeBound);
/*     */       }
/*     */     }
/* 197 */     return count;
/*     */   }
/*     */ 
/*     */   public double getNonPhaseVehicleCount(int StartRoute) {
/* 201 */     double count = 0.0D;
/* 202 */     for (int i = 0; i < this.NumJob.length; i++) {
/* 203 */       if (i != StartRoute) {
/* 204 */         count += getPhaseVehicleCount(i);
/*     */       }
/*     */     }
/* 207 */     return count;
/*     */   }
/*     */ 
/*     */   public void loadSelf(String dataStr) {
/* 211 */     String[] phasedData = GlobalString.tokenize(dataStr, "]");
/* 212 */     if (phasedData.length != this.NumJob.length) return;
/* 213 */     int jobIndex = 0;
/* 214 */     for (int i = 0; i < this.NumJob.length; i++) {
/* 215 */       String subData = phasedData[i].substring(1, phasedData[i].length());
/* 216 */       String[] indData = GlobalString.tokenize(subData, ";");
/* 217 */       this.NumJob[i] = indData.length;
/* 218 */       for (int j = 0; j < this.NumJob[i]; j++) {
/* 219 */         String[] jobData = GlobalString.tokenize(indData[j], ",");
/* 220 */         this.JobStart[jobIndex] = new Integer(jobData[0]).intValue();
/* 221 */         this.JobEnd[jobIndex] = new Integer(jobData[1]).intValue();
/* 222 */         this.Count[jobIndex] = new Double(jobData[2]).doubleValue();
/* 223 */         this.Weight[jobIndex] = new Double(jobData[3]).doubleValue();
/* 224 */         jobIndex++;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public String printSelf() {
/* 230 */     String selfInfo = "DPData:";
/* 231 */     int index = 0;
/* 232 */     for (int i = 0; i < this.NumJob.length; i++) {
/* 233 */       selfInfo = selfInfo + "[";
/* 234 */       for (int j = 0; j < this.NumJob[i]; j++) {
/* 235 */         selfInfo = selfInfo + this.JobStart[index] + "," + this.JobEnd[index] + "," + ScaleSettings.CountFormatter.format(this.Count[index]) + "," + ScaleSettings.CountFormatter.format(this.Weight[index]);
/* 236 */         if (j != this.NumJob[i] - 1) {
/* 237 */           selfInfo = selfInfo + ";";
/*     */         }
/* 239 */         index++;
/*     */       }
/* 241 */       selfInfo = selfInfo + "]";
/*     */     }
/* 243 */     return selfInfo;
/*     */   }
/*     */ }

/* Location:           /usr0/home/ahawkes/DecTLC-devel.jar
 * Qualified Name:     TLC.control.intersection.transition.BasicJobBlockSData
 * JD-Core Version:    0.6.2
 */