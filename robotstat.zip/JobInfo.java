package TLC.control.intersection.transition;
import TLC.component.junction.structure.IInnerPhaseInpEdgeEngine;
import TLC.component.junction.structure.innerLogic.IInternalDefaultPhaseBoundEngine;
import TLC.component.junction.structure.innerLogic.IInternalPhaseSkipStatusEngine;
import TLC.global.BasicLog;
import TLC.global.BasicMath;
import TLC.setting.ScaleSettings;
import java.util.Arrays;
import org.apache.log4j.Logger;
 
public class JobInfo
{ 
	public int phaseInfo = 0;

}