/*     */ package TLC.control.intersection.transition;
/*     */ 
/*     */ import TLC.component.junction.structure.IInnerPhaseInpEdgeEngine;
/*     */ import TLC.component.junction.structure.innerLogic.IInternalDefaultPhaseBoundEngine;
/*     */ import TLC.component.junction.structure.innerLogic.IInternalPhaseSkipStatusEngine;
/*     */ import TLC.global.BasicLog;
/*     */ import TLC.global.BasicMath;
/*     */ import TLC.setting.ScaleSettings;
/*     */ import java.util.Arrays;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class JobBlockSData extends BasicJobBlockSData
/*     */ {
/*     */   public double[][] packetEdgeRatios;
/*     */   public IInternalPhaseSkipStatusEngine internalPhaseSkipStatusEngine;
/*     */   private IInnerPhaseInpEdgeEngine innerPhaseInpEdgeEngine;
/*     */   private int[] subjobIndices;
/*     */ 
/*     */   public void initiate(IInnerPhaseInpEdgeEngine innerPhaseInpEdgeEngine, int maxJobNumber)
/*     */   {
/*  35 */     this.innerPhaseInpEdgeEngine = innerPhaseInpEdgeEngine;
/*  36 */     int activePhaseNumber = innerPhaseInpEdgeEngine.getInternalPhaseNumber();
/*     */ 
/*  38 */     super.initiate(activePhaseNumber, maxJobNumber);
/*     */ 
/*  40 */     int inputEdgeNumber = innerPhaseInpEdgeEngine.getInpEdgeNumber();
/*  41 */     this.packetEdgeRatios = new double[maxJobNumber][inputEdgeNumber];
/*  42 */     for (int i = 0; i < maxJobNumber; i++) {
/*  43 */       Arrays.fill(this.packetEdgeRatios[i], 0.0D);
/*     */     }
/*     */ 
/*  46 */     this.subjobIndices = new int[inputEdgeNumber];
/*     */   }
/*     */ 
/*     */   public void reInitJobs(int StartRoute, int scaledMinExt) {
/*  50 */     if (this.NumJob[StartRoute] == 0) return;
/*  51 */     int startJobIndex = getStartIndex(StartRoute);
/*     */ 
/*  53 */     if ((this.JobStart[startJobIndex] > scaledMinExt) || (this.JobEnd[startJobIndex] < scaledMinExt)) return;
/*     */ 
/*  55 */     int totalJobNumber = getStartIndex(this.NumJob.length);
/*     */ 
/*  57 */     if (this.JobEnd[startJobIndex] == this.JobStart[startJobIndex]) return;
/*     */ 
/*  59 */     System.arraycopy(this.Count, startJobIndex, this.Count, startJobIndex + 1, totalJobNumber - startJobIndex);
/*  60 */     System.arraycopy(this.Weight, startJobIndex, this.Weight, startJobIndex + 1, totalJobNumber - startJobIndex);
/*  61 */     System.arraycopy(this.JobStart, startJobIndex, this.JobStart, startJobIndex + 1, totalJobNumber - startJobIndex);
/*  62 */     System.arraycopy(this.JobEnd, startJobIndex, this.JobEnd, startJobIndex + 1, totalJobNumber - startJobIndex);
/*     */ 
/*  64 */     double remRatio = (this.JobEnd[startJobIndex] - scaledMinExt) / (this.JobEnd[startJobIndex] - this.JobStart[startJobIndex]);
/*     */ 
/*  66 */     this.Count[(startJobIndex + 1)] *= remRatio;
/*  67 */     this.Weight[(startJobIndex + 1)] *= remRatio;
/*  68 */     this.JobStart[(startJobIndex + 1)] = scaledMinExt;
/*     */ 
/*  70 */     this.Count[startJobIndex] *= (1.0D - remRatio);
/*  71 */     this.Weight[startJobIndex] *= (1.0D - remRatio);
/*  72 */     this.JobEnd[startJobIndex] = scaledMinExt;
/*     */ 
/*  74 */     this.NumJob[StartRoute] += 1;
/*     */   }
/*     */ 
/*     */   private void copyEdgeRatios(int startJobIndex)
/*     */   {
/*  79 */     int totalJobNumber = getStartIndex(this.NumJob.length);
/*  80 */     for (int j = totalJobNumber - 1; j > startJobIndex; j--)
/*  81 */       System.arraycopy(this.packetEdgeRatios[(j - 1)], 0, this.packetEdgeRatios[j], 0, this.packetEdgeRatios[j].length);
/*     */   }
/*     */ 
/*     */   protected double cutJob(int routeIndex, int startJobIndex, int cuttingTimePoint)
/*     */   {
/*  86 */     double remRatio = super.cutJob(routeIndex, startJobIndex, cuttingTimePoint);
/*  87 */     if ((remRatio > 0.0D) && (remRatio < 1.0D)) {
/*  88 */       copyEdgeRatios(startJobIndex);
/*     */     }
/*  90 */     return remRatio;
/*     */   }
/*     */ 
/*     */   public int preprocessJobs(int routeIndex, int currTimePoint, int TimeInterval) {
			  	int startJobIndex = getStartIndex(routeIndex);
			  	int i = 0;
			  	int cutTimes = 0;
			  	while (i< NumJob[routeIndex]) {
			    	double remRatio = cutJob(routeIndex, startJobIndex, currTimePoint);
			    	if (remRatio > 1) {
			    		currTimePoint = JobStart[startJobIndex]+TimeInterval;
			    		continue;
			    	}
			  		if (remRatio > 0) {
			  			currTimePoint += TimeInterval;
			  			cutTimes++;
			  		}
			  		i++;
			  		startJobIndex++;
			  	}
			  	return cutTimes;
			}
/*     */ 
/*     */   public void preprocessJobs(int StartRoute, int remainTime, IInternalDefaultPhaseBoundEngine internalDefaultPhaseBoundEngine, SinglePhaseEdgeInfo singlePhaseEdgeInfo, double scaleRatio) {
/* 115 */     int cutTimes = 0;
/* 116 */     if (SDPSettings.UsePostProcess > 0) {
/* 117 */       for (int i = 0; i < this.NumJob.length; i++) {
/* 118 */         int currTimePoint = BasicMath.ratioedRint(remainTime, scaleRatio);
/* 119 */         int TimeInterval = BasicMath.ratioedRint(internalDefaultPhaseBoundEngine.getMaxDurationAt(i), scaleRatio) - singlePhaseEdgeInfo.StartupTime[i];
/* 120 */         if ((i != StartRoute) || (currTimePoint == 0)) currTimePoint = TimeInterval;
/* 121 */         if (this.internalPhaseSkipStatusEngine.isSkippableAt(i)) {
/* 122 */           if (this.NumJob[i] > 0) super.boundJob(i, TimeInterval); 
/*     */         }
/* 124 */         else {
						int cutTime = preprocessJobs(i, currTimePoint, TimeInterval);
/* 125 */           if ((SDPSettings.UsePostProcess > 2) && (cutTime > cutTimes)) {
/* 126 */             cutTimes = cutTime;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 132 */     if (SDPSettings.UsePostProcess > 1)
/*     */     {
/* 134 */       for (int i = 0; i < internalDefaultPhaseBoundEngine.getInternalPhaseNumber(); i++)
/* 135 */         if (i != StartRoute) addEmptyJob(i, internalDefaultPhaseBoundEngine, singlePhaseEdgeInfo, scaleRatio, cutTimes + 1);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addEmptyJob(int i, IInternalDefaultPhaseBoundEngine internalDefaultPhaseBoundEngine, SinglePhaseEdgeInfo singlePhaseEdgeInfo, double scaleRatio, int cutTimes)
/*     */   {
/* 141 */     if (this.NumJob[i] >= cutTimes) return;
/* 142 */     int start = 0;
/* 143 */     int jobIndex = getStartIndex(i) + this.NumJob[i];
/* 144 */     if (this.NumJob[i] > 0) {
/* 145 */       start = this.JobEnd[(jobIndex - 1)];
/*     */     }
/* 147 */     int duration = BasicMath.ratioedRint(internalDefaultPhaseBoundEngine.getMinDurationAt(i), scaleRatio) - singlePhaseEdgeInfo.StartupTime[i];
/* 148 */     while (this.NumJob[i] < cutTimes) {
/* 149 */       copyJob(i, jobIndex);
/* 150 */       copyEdgeRatios(jobIndex);
/*     */ 
/* 152 */       this.JobStart[jobIndex] = start;
/* 153 */       start += duration;
/* 154 */       this.JobEnd[jobIndex] = start;
/* 155 */       this.Count[jobIndex] = 0.0D;
/* 156 */       this.Weight[jobIndex] = ScaleSettings.MinVehCount;
/* 157 */       for (int j = 0; j < this.packetEdgeRatios[jobIndex].length; j++) {
/* 158 */         this.packetEdgeRatios[jobIndex][j] = 0.0D;
/*     */       }
/* 160 */       jobIndex++;
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isCountValid() {
/* 165 */     int totalJobNumber = getStartIndex(this.NumJob.length);
/* 166 */     for (int i = 0; i < totalJobNumber; i++) {
/* 167 */       if (this.Weight[i] < 0.0D) {
/* 168 */         return false;
/*     */       }
/* 170 */       for (int j = 0; j < this.packetEdgeRatios[i].length; j++) {
/* 171 */         if (this.packetEdgeRatios[i][j] < 0.0D) {
/* 172 */           return false;
/*     */         }
/*     */       }
/*     */     }
/* 176 */     return true;
/*     */   }
/*     */ 
/*     */   public void initJobs(int StartRoute, JobBlockMData dpData2, PhaseExtensionChecker phaseExtensionChecker, InternalPhaseInfo internalPhaseInfo, SinglePhaseEdgeInfo singlePhaseEdgeInfo) {
/* 180 */     int activePhaseNumber = this.innerPhaseInpEdgeEngine.getInternalPhaseNumber();
/*     */ 
/* 182 */     int jobIndex = 0;
/* 183 */     Arrays.fill(this.JobEnd, 0);
/* 184 */     Arrays.fill(this.NumJob, 0);
/*     */ 
/* 186 */     for (int i = 0; i < activePhaseNumber; i++) {
/* 187 */       int nonConflictEdgeNumber = this.innerPhaseInpEdgeEngine.getInternalInpEdgeNumber(i);
/* 188 */       for (int j = 0; j < nonConflictEdgeNumber; j++) {
/* 189 */         if (this.internalPhaseSkipStatusEngine.isSkippableAt(i)) {
/* 190 */           dpData2.NumJob[i][j] = Math.min(1, dpData2.NumJob[i][j]);
/*     */         }
/*     */       }
/* 193 */       if (nonConflictEdgeNumber == 1) {
/* 194 */         int actualInpEdgeIndex = this.innerPhaseInpEdgeEngine.getActualInpEdgeIndexAt(i, 0);
/* 195 */         this.NumJob[i] = dpData2.NumJob[i][0];
/*     */ 
/* 197 */         for (int k = 0; k < this.NumJob[i]; k++) {
/* 198 */           this.JobStart[jobIndex] = dpData2.PhaseJobStarts[k][i][0];
/* 199 */           this.JobEnd[jobIndex] = dpData2.PhaseJobEnds[k][i][0];
/* 200 */           this.Count[jobIndex] = dpData2.PhaseWeights[k][i][0];
/* 201 */           this.Weight[jobIndex] = this.Count[jobIndex];
                    this.Info[jobIndex] = dpData2.getJobInfo(i, 0, k);
/* 202 */           Arrays.fill(this.packetEdgeRatios[jobIndex], 0.0D);
/* 203 */           this.packetEdgeRatios[jobIndex][actualInpEdgeIndex] = 1.0D;
/* 204 */           jobIndex++;
/*     */         }
/*     */       } else {
/* 207 */         Arrays.fill(this.subjobIndices, 0);
/* 208 */         int minIndex = -1;
/* 209 */         this.NumJob[i] = 0;
/*     */ 
/* 211 */         int phaseJobStartIndex = jobIndex;
/*     */         while (true) {
/* 213 */           int minStart = 2147483647;
/* 214 */           for (int j = 0; j < nonConflictEdgeNumber; j++) {
/* 215 */             if ((this.subjobIndices[j] < dpData2.NumJob[i][j]) && (dpData2.PhaseJobStarts[this.subjobIndices[j]][i][j] < minStart)) {
/* 216 */               minStart = dpData2.PhaseJobStarts[this.subjobIndices[j]][i][j];
/* 217 */               minIndex = j;
/*     */             }
/*     */           }
/* 220 */           if (minStart == 2147483647) break;
/* 221 */           int actualInpEdgeIndex = this.innerPhaseInpEdgeEngine.getActualInpEdgeIndexAt(i, minIndex);
/* 222 */           if ((this.NumJob[i] == 0) || ((!this.internalPhaseSkipStatusEngine.isSkippableAt(i)) && (dpData2.PhaseJobStarts[this.subjobIndices[minIndex]][i][minIndex] > this.JobEnd[(jobIndex - 1)]))) {
/* 223 */             Arrays.fill(this.packetEdgeRatios[jobIndex], 0.0D);
/* 224 */             this.JobStart[jobIndex] = dpData2.PhaseJobStarts[this.subjobIndices[minIndex]][i][minIndex];
/* 225 */             this.JobEnd[jobIndex] = dpData2.PhaseJobEnds[this.subjobIndices[minIndex]][i][minIndex];
/* 226 */             this.Count[jobIndex] = dpData2.PhaseWeights[this.subjobIndices[minIndex]][i][minIndex];
/* 227 */             this.Weight[jobIndex] = this.Count[jobIndex];
/* 228 */             this.packetEdgeRatios[jobIndex][actualInpEdgeIndex] = this.Count[jobIndex];
                      this.Info[jobIndex] = dpData2.getJobInfo(i, minIndex, this.subjobIndices[minIndex]);
/* 229 */             this.NumJob[i] += 1;
/* 230 */             jobIndex++;
/*     */           } else {
/* 232 */             this.JobEnd[(jobIndex - 1)] = Math.max(this.JobEnd[(jobIndex - 1)], dpData2.PhaseJobEnds[this.subjobIndices[minIndex]][i][minIndex]);
/* 233 */             this.Count[(jobIndex - 1)] += dpData2.PhaseWeights[this.subjobIndices[minIndex]][i][minIndex];
/* 234 */             this.Weight[(jobIndex - 1)] = this.Count[(jobIndex - 1)];
/* 235 */             this.packetEdgeRatios[(jobIndex - 1)][actualInpEdgeIndex] += dpData2.PhaseWeights[this.subjobIndices[minIndex]][i][minIndex];
                      this.Info[jobIndex-1] = dpData2.getJobInfo(i, minIndex, this.subjobIndices[minIndex]);
/*     */           }
/* 237 */           this.subjobIndices[minIndex] += 1;
/*     */         }
/*     */ 
/* 241 */         int minQueueEnd = 2147483647; int maxQueueEnd = 0;
/*     */ 
/* 243 */         if (SDPSettings.QueueCutType > 0) {
/* 244 */           for (int j = 0; j < nonConflictEdgeNumber; j++) {
/* 245 */             if ((dpData2.NumJob[i][j] > 0) && 
/* 246 */               (dpData2.PhaseJobStarts[0][i][j] == 0)) {
/* 247 */               minQueueEnd = Math.min(minQueueEnd, dpData2.PhaseJobEnds[0][i][j]);
/* 248 */               maxQueueEnd = Math.max(maxQueueEnd, dpData2.PhaseJobEnds[0][i][j]);
/*     */             }
/*     */           }
/*     */ 
/* 252 */           if (minQueueEnd == 2147483647) {
/* 253 */             minQueueEnd = 0;
/*     */           }
/*     */         }
/*     */ 
/* 257 */         if ((SDPSettings.QueueCutType > 0) && (minQueueEnd > 1) && (minQueueEnd < this.JobEnd[phaseJobStartIndex])) {
/* 258 */           shift(phaseJobStartIndex, jobIndex);
/* 259 */           //this.NumJob[i] += 1;
/* 260 */           jobIndex++;
/*     */ 
/* 262 */           this.JobStart[(phaseJobStartIndex + 1)] = minQueueEnd;
/* 263 */           this.JobEnd[phaseJobStartIndex] = minQueueEnd;
/* 264 */           Arrays.fill(this.packetEdgeRatios[phaseJobStartIndex], 0.0D);
/* 265 */           this.Count[phaseJobStartIndex] = 0.0D;
/* 266 */           this.Weight[phaseJobStartIndex] = 0.0D;
/* 267 */           for (int j = 0; j < nonConflictEdgeNumber; j++){
/* 268 */             if ((dpData2.NumJob[i][j] > 0) && 
/* 269 */               (dpData2.PhaseJobStarts[0][i][j] == 0)) {
/* 270 */               double actualSubCount = dpData2.PhaseWeights[0][i][j];
/* 271 */               if (dpData2.PhaseJobEnds[0][i][j] <= 0) {
/* 272 */                 BasicLog.logger.warn("dpData2.PhaseJobEnds[0][" + i + "][+" + j + "] = " + dpData2.PhaseJobEnds[0][i][j]);
/*     */               }
/*     */               else {
/* 275 */                 double ratio = Math.min(minQueueEnd, dpData2.PhaseJobEnds[0][i][j]) / dpData2.PhaseJobEnds[0][i][j];
/* 276 */                 actualSubCount *= ratio;
/* 277 */                 if (actualSubCount <= 0.0D) {
/* 278 */                   BasicLog.logger.warn("actualSubCount[" + i + "][+" + j + "] = " + actualSubCount);
/*     */                 }
/*     */                 else {
/* 281 */                   int actualInpEdgeIndex = this.innerPhaseInpEdgeEngine.getActualInpEdgeIndexAt(i, j);
/* 282 */                   this.packetEdgeRatios[phaseJobStartIndex][actualInpEdgeIndex] = actualSubCount;
/* 283 */                   this.Count[phaseJobStartIndex] += actualSubCount;
/* 284 */                   this.Weight[phaseJobStartIndex] = this.Count[phaseJobStartIndex];
/*     */ 
/* 286 */                   this.packetEdgeRatios[(phaseJobStartIndex + 1)][actualInpEdgeIndex] -= actualSubCount;
/* 287 */                   this.packetEdgeRatios[(phaseJobStartIndex + 1)][actualInpEdgeIndex] = Math.max(0.0D, this.packetEdgeRatios[(phaseJobStartIndex + 1)][actualInpEdgeIndex]);
/* 288 */                   this.Count[(phaseJobStartIndex + 1)] -= actualSubCount;
/* 289 */                   this.Count[(phaseJobStartIndex + 1)] = Math.max(this.Count[(phaseJobStartIndex + 1)], 0.0D);
/* 290 */                   this.Weight[(phaseJobStartIndex + 1)] = this.Count[(phaseJobStartIndex + 1)];
/*     */                 }
/*     */               }
/*     */             }
                    this.Info[phaseJobStartIndex] = dpData2.getJobInfo(i, j, 0);
                    }
/* 294 */           phaseJobStartIndex++;
/*     */         }
/*     */ 
/* 297 */         if ((SDPSettings.QueueCutType > 1) && (maxQueueEnd > minQueueEnd) && (maxQueueEnd < this.JobEnd[phaseJobStartIndex])) {
/* 298 */           shift(phaseJobStartIndex, jobIndex);
/* 299 */           this.NumJob[i] += 1;
/* 300 */           jobIndex++;
/*     */ 
/* 302 */           this.JobStart[(phaseJobStartIndex + 1)] = maxQueueEnd;
/* 303 */           this.JobEnd[phaseJobStartIndex] = maxQueueEnd;
/* 304 */           Arrays.fill(this.packetEdgeRatios[phaseJobStartIndex], 0.0D);
/* 305 */           this.Count[phaseJobStartIndex] = 0.0D;
/* 306 */           this.Weight[phaseJobStartIndex] = 0.0D;
/* 307 */           for (int j = 0; j < nonConflictEdgeNumber; j++) {
/* 308 */             if ((dpData2.NumJob[i][j] > 0) && 
/* 309 */               (dpData2.PhaseJobStarts[0][i][j] == 0) && (dpData2.PhaseJobEnds[0][i][j] > minQueueEnd)) {
/* 310 */               double actualSubCount = dpData2.PhaseWeights[0][i][j];
/* 311 */               if (dpData2.PhaseJobEnds[0][i][j] <= 0) {
/* 312 */                 BasicLog.logger.warn("dpData2.PhaseJobEnds[0][" + i + "][+" + j + "] = " + dpData2.PhaseJobEnds[0][i][j]);
/*     */               }
/*     */               else {
/* 315 */                 double ratio = (dpData2.PhaseJobEnds[0][i][j] - minQueueEnd) / dpData2.PhaseJobEnds[0][i][j];
/* 316 */                 actualSubCount *= ratio;
/* 317 */                 if (actualSubCount <= 0.0D) {
/* 318 */                   BasicLog.logger.warn("actualSubCount[" + i + "][+" + j + "] = " + actualSubCount);
/*     */                 }
/*     */                 else {
/* 321 */                   int actualInpEdgeIndex = this.innerPhaseInpEdgeEngine.getActualInpEdgeIndexAt(i, j);
/* 322 */                   this.packetEdgeRatios[phaseJobStartIndex][actualInpEdgeIndex] = actualSubCount;
/* 323 */                   this.Count[phaseJobStartIndex] += actualSubCount;
/* 324 */                   this.Weight[phaseJobStartIndex] = this.Count[phaseJobStartIndex];
/*     */ 
/* 326 */                   this.packetEdgeRatios[(phaseJobStartIndex + 1)][actualInpEdgeIndex] -= actualSubCount;
/* 327 */                   this.packetEdgeRatios[(phaseJobStartIndex + 1)][actualInpEdgeIndex] = Math.max(0.0D, this.packetEdgeRatios[(phaseJobStartIndex + 1)][actualInpEdgeIndex]);
/* 328 */                   this.Count[(phaseJobStartIndex + 1)] -= actualSubCount;
/* 329 */                   this.Count[(phaseJobStartIndex + 1)] = Math.max(this.Count[(phaseJobStartIndex + 1)], 0.0D);
/* 330 */                   this.Weight[(phaseJobStartIndex + 1)] = this.Count[(phaseJobStartIndex + 1)];
/*     */                 }
/*     */               }
/*     */             }
                     this.Info[phaseJobStartIndex] = dpData2.getJobInfo(i, j, 0);
/*     */           }
/*     */         }
/* 336 */         for (int j = jobIndex - this.NumJob[i]; j < jobIndex; j++)
/* 337 */           for (int k = 0; k < this.packetEdgeRatios[j].length; k++) {
/* 338 */             this.packetEdgeRatios[j][k] /= this.Count[j];
/* 339 */             if (this.packetEdgeRatios[j][k] - 1.0D > 0.01D)
/* 340 */               BasicLog.logger.warn("packetEdgeRatios(job, edge)= " + this.packetEdgeRatios[j][k] + "(" + j + "," + k + "): Count=" + this.Count[j]);
/*     */           }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void shift(int minJobIndex, int maxJobIndex)
/*     */   {
/* 349 */     for (int jindex = maxJobIndex - 1; jindex >= minJobIndex; jindex--) {
/* 350 */       this.JobStart[(jindex + 1)] = this.JobStart[jindex];
/* 351 */       this.JobEnd[(jindex + 1)] = this.JobEnd[jindex];
/* 352 */       this.Weight[(jindex + 1)] = this.Weight[jindex];
/* 353 */       this.Count[(jindex + 1)] = this.Count[jindex];
                this.Info[(jindex + 1)] = this.Info[jindex];
/* 354 */       System.arraycopy(this.packetEdgeRatios[jindex], 0, this.packetEdgeRatios[(jindex + 1)], 0, this.packetEdgeRatios[jindex].length);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /usr0/home/ahawkes/DecTLC-devel.jar
 * Qualified Name:     TLC.control.intersection.transition.JobBlockSData
 * JD-Core Version:    0.6.2
 */