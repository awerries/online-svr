/*    */ package TLC.control.intersection.transition;
/*    */ 
/*    */ import TLC.global.GlobalCounter;
/*    */ 
/*    */ public class JobBlockHandler
/*    */ {
/*    */   public static void execute(JobBlockDeltaData jobBlockDeltaData, int jStart, int jEnd, double jWeight, JobInfo jInfo, int prevEnd, double satFlowRate, boolean isSoft)
/*    */   {
/* 19 */     GlobalCounter.DPCounts += 1;
/* 20 */     if (isSoft)
/* 21 */       executeSoft(jobBlockDeltaData, jStart, jEnd, jWeight, jInfo, prevEnd, satFlowRate);
/*    */     else
/* 23 */       executeHard(jobBlockDeltaData, jStart, jEnd, jWeight, jInfo, prevEnd);
/*    */   }
          public static void execute(JobBlockDeltaData jobBlockDeltaData, int jStart, int jEnd, double jWeight, int prevEnd, double satFlowRate, boolean isSoft)
/*    */   {
/* 19 */     GlobalCounter.DPCounts += 1;
/* 20 */     if (isSoft)
/* 21 */       executeSoft(jobBlockDeltaData, jStart, jEnd, jWeight, prevEnd, satFlowRate);
/*    */     else
/* 23 */       executeHard(jobBlockDeltaData, jStart, jEnd, jWeight, prevEnd);
/*    */   }
/*    */ 
/*    */   public static int getDeltaT(int jStart, int jLength, double jWeight, int prevEnd, double satFlowRate)
/*    */   {
/* 30 */     int deltaT = prevEnd - jStart;
/* 31 */     if (deltaT > 0) {
/* 32 */       double jFlowRate = jWeight / jLength;
/* 33 */       double deltaFlowRate = satFlowRate - jFlowRate;
/* 34 */       if ((deltaFlowRate <= 0.0D) || (jLength <= deltaT))
/* 35 */         deltaT = jLength;
/*    */       else {
/* 37 */         deltaT += (int)(deltaT * jFlowRate / deltaFlowRate);
/*    */       }
/*    */     }
/* 40 */     return deltaT;
/*    */   }
/*    */ 
/*    */   public static void executeSoft(JobBlockDeltaData jobBlockDeltaData, int jStart, int jEnd, double jWeight, JobInfo jInfo, int prevEnd, double satFlowRate)
/*    */   {
/* 46 */     int deltaEnd = prevEnd - jStart;
/*    */     double deltaLateness;
/* 48 */     if (deltaEnd > 0) {
/* 49 */       int jLength = jEnd - jStart;
/* 50 */       int jLengthS = (int)Math.rint(jWeight / satFlowRate);
/* 51 */       int jLengthD = jLength - jLengthS;

/* 52 */       if (jLengthD <= 0)
/*    */       {
/* 54 */         deltaLateness = deltaEnd * jWeight;
/*    */       } else {
/* 56 */         double jWeightS = jWeight * (jLengthS / jLength);
/* 57 */         if (deltaEnd <= jLengthD) {
/* 58 */           deltaLateness = deltaEnd * (jWeightS + 0.5D * deltaEnd * (jWeight - jWeightS) / jLengthD);
/* 59 */           deltaEnd = 0;
/*    */         } else {
/* 61 */           deltaLateness = deltaEnd * jWeight - 0.5D * jLengthD * (jWeight - jWeightS);
/* 62 */           deltaEnd -= jLengthD;
/*    */         }
/*    */       }
/*    */     } else {
/* 66 */       deltaEnd = 0;
/* 67 */       deltaLateness = 0.0D;
/*    */     }
/* 69 */     jobBlockDeltaData.deltaLateness = deltaLateness;// * (1.0D + jInfo.phaseInfo*2);
/* 70 */     jobBlockDeltaData.deltaEnd = deltaEnd;
/*    */   }
/*    */ 
/*    */   public static void executeHard(JobBlockDeltaData jobBlockDeltaData, int jStart, int jEnd, double jWeight,  JobInfo jInfo, int prevEnd) {
/* 74 */     jobBlockDeltaData.deltaEnd = Math.max(prevEnd - jStart, 0);
/* 75 */     jobBlockDeltaData.deltaLateness = (jobBlockDeltaData.deltaEnd * jWeight);
/*    */   }

/*    */   public static void executeSoft(JobBlockDeltaData jobBlockDeltaData, int jStart, int jEnd, double jWeight, int prevEnd, double satFlowRate)
/*    */   {
/* 46 */     int deltaEnd = prevEnd - jStart;
/*    */     double deltaLateness;
/* 48 */     if (deltaEnd > 0) {
/* 49 */       int jLength = jEnd - jStart;
/* 50 */       int jLengthS = (int)Math.rint(jWeight / satFlowRate);
/* 51 */       int jLengthD = jLength - jLengthS;

/* 52 */       if (jLengthD <= 0)
/*    */       {
/* 54 */         deltaLateness = deltaEnd * jWeight;
/*    */       } else {
/* 56 */         double jWeightS = jWeight * (jLengthS / jLength);
/* 57 */         if (deltaEnd <= jLengthD) {
/* 58 */           deltaLateness = deltaEnd * (jWeightS + 0.5D * deltaEnd * (jWeight - jWeightS) / jLengthD);
/* 59 */           deltaEnd = 0;
/*    */         } else {
/* 61 */           deltaLateness = deltaEnd * jWeight - 0.5D * jLengthD * (jWeight - jWeightS);
/* 62 */           deltaEnd -= jLengthD;
/*    */         }
/*    */       }
/*    */     } else {
/* 66 */       deltaEnd = 0;
/* 67 */       deltaLateness = 0.0D;
/*    */     }
/* 69 */     jobBlockDeltaData.deltaLateness = deltaLateness;
/* 70 */     jobBlockDeltaData.deltaEnd = deltaEnd;
/*    */   }
/*    */   public static void executeHard(JobBlockDeltaData jobBlockDeltaData, int jStart, int jEnd, double jWeight,  int prevEnd) {
/* 74 */     jobBlockDeltaData.deltaEnd = Math.max(prevEnd - jStart, 0);
/* 75 */     jobBlockDeltaData.deltaLateness = (jobBlockDeltaData.deltaEnd * jWeight);
/*    */   }
/*    */ }



/* Location:           /usr0/home/ahawkes/DecTLC-devel.jar
 * Qualified Name:     TLC.control.intersection.transition.JobBlockHandler
 * JD-Core Version:    0.6.2
 */
